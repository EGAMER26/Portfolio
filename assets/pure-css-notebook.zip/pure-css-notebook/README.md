# Pure CSS Notebook

A Pen created on CodePen.io. Original URL: [https://codepen.io/skimberk1/pen/neRoGv](https://codepen.io/skimberk1/pen/neRoGv).

It is also completely scalable as it's size depends entirely on it's font size. 

Inspired by this Dribble shot: http://dribbble.com/shots/1148286-Simple-Notebook